﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_workassign : System.Web.UI.Page
{
    Class1 c = new Class1();
    public void clear()
    {
        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox3.Text = "";
    }
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        c.cmd.CommandText = "select * from work";
        c.ds.Clear();
        c.adp.Fill(c.ds, "vt");
        c.dr = c.ds.Tables["vt"].NewRow();
        c.dr["empid"] = TextBox1.Text;
        c.dr["descr"] = TextBox2.Text;
        c.dr["allot"] = TextBox3.Text;
        c.ds.Tables["vt"].Rows.Add(c.dr);
        c.scb = new System.Data.SqlClient.SqlCommandBuilder(c.adp);
        c.adp.Update(c.ds.Tables["vt"]);
        Response.Write("<script>alert('work will be alloted')</script>");
        clear();
    }
}