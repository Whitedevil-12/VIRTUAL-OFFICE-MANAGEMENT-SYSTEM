﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_Change_Password : System.Web.UI.Page
{
    Class1 c = new Class1();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_click_Click(object sender, EventArgs e)
    {
        c.cmd.CommandText = "update acctype set password='" + txt_newpass.Text + "' where username='" + txt_lid.Text + "' and password='" + txt_oldpass0.Text + "'";
        c.con.Open();
        if (c.cmd.ExecuteNonQuery() > 0)
        {
            Response.Write("<script>alert('change successful')</script>");
            c.con.Close();
        }
        else
        {
            Response.Write("<script>alert('failed')</script>");
        }
    }
}