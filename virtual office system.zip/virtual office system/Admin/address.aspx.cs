﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_address : System.Web.UI.Page
{
    Class1 c = new Class1();
    public void clear()
    {
        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox3.Text = "";
        TextBox4.Text = "";
        TextBox5.Text = "";

    }
    protected void Page_Load(object sender, EventArgs e)
    {
        TextBox6.Text = c.autoid("C", "select * from work");
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        c.cmd.CommandText = "select * from addres1";
        c.ds.Clear();
        c.adp.Fill(c.ds, "reg");
        c.dr = c.ds.Tables["reg"].NewRow();
        c.dr["id"] = TextBox6.Text;
        c.dr["name"] = TextBox1.Text;
        c.dr["addr"] = TextBox2.Text;
        c.dr["city"] = TextBox3.Text;
        c.dr["email"] = TextBox4.Text;
        c.dr["phone"] = TextBox5.Text;
        c.ds.Tables["reg"].Rows.Add(c.dr);
        c.scb = new System.Data.SqlClient.SqlCommandBuilder(c.adp);
        c.adp.Update(c.ds.Tables["reg"]);
        Response.Write("<script>alert('New Contact successfully added')</script>");
        clear();
    }
}