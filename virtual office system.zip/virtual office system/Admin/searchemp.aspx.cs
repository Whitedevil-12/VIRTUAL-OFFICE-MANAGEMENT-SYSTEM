﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_empreg : System.Web.UI.Page
{
    Class1 c = new Class1();
    
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
  
    protected void btn_reset_Click(object sender, EventArgs e)
    {
         c.cmd.CommandText = "select * from empreg where empid='" + txt_lid.Text + "'";
        c.adp.Fill(c.ds, "reg");
        if (c.ds.Tables["reg"].Rows.Count > 0)
        {

            lblname.Text = c.ds.Tables["reg"].Rows[0][1].ToString();
            lblPass.Text = c.ds.Tables["reg"].Rows[0][2].ToString();
            lblsex.Text = c.ds.Tables["reg"].Rows[0][3].ToString();
            lbldate.Text = c.ds.Tables["reg"].Rows[0][4].ToString();
            lbldepartment.Text = c.ds.Tables["reg"].Rows[0][5].ToString();
            lbldesignation.Text = c.ds.Tables["reg"].Rows[0][6].ToString();
            lblPhone.Text = c.ds.Tables["reg"].Rows[0][7].ToString();
            lbladd.Text = c.ds.Tables["reg"].Rows[0][8].ToString();
            lblmail.Text = c.ds.Tables["reg"].Rows[0][9].ToString();
            lblcity.Text = c.ds.Tables["reg"].Rows[0][10].ToString();
        }
    }



    protected void Button1_Click(object sender, EventArgs e)
    {
        c.cmd.CommandText = "select * from empreg where name='" + txt_lid0.Text + "'";
        c.adp.Fill(c.ds, "reg");
        if (c.ds.Tables["reg"].Rows.Count > 0)
        {

            lblname0.Text = c.ds.Tables["reg"].Rows[0][0].ToString();
            lblPass0.Text = c.ds.Tables["reg"].Rows[0][2].ToString();
            lblsex0.Text = c.ds.Tables["reg"].Rows[0][3].ToString();
            lbldate0.Text = c.ds.Tables["reg"].Rows[0][4].ToString();
            lbldepartment0.Text = c.ds.Tables["reg"].Rows[0][5].ToString();
            lbldesignation0.Text = c.ds.Tables["reg"].Rows[0][6].ToString();
            lblPhone0.Text = c.ds.Tables["reg"].Rows[0][7].ToString();
            lbladd0.Text = c.ds.Tables["reg"].Rows[0][8].ToString();
            lblmail0.Text = c.ds.Tables["reg"].Rows[0][9].ToString();
            lblcity0.Text = c.ds.Tables["reg"].Rows[0][10].ToString();
        }
    }
    protected void RadioButton1_CheckedChanged(object sender, EventArgs e)
    {
        if (RadioButton1.Checked)
        {
            MultiView1.SetActiveView(View1);
        }
    }
    protected void RadioButton2_CheckedChanged(object sender, EventArgs e)
    {
        if (RadioButton2.Checked)
        {
            MultiView1.SetActiveView(View2);
        }
    }
}
