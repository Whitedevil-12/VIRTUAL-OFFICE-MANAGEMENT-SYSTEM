﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_empreg : System.Web.UI.Page
{
    Class1 c = new Class1();
    public void clear()
    {
        txt_name.Text = "";
        txt_lid.Text = "";
        txt_pass.Text = "";
        txt_conpass.Text = "";
        ddl_department.SelectedItem.Text = "--select--";
        txt_phno.Text = "";
        txt_add.Text = "";
        txt_email.Text = "";
        DropDownList1.SelectedItem.Text = "--select--";
        DropDownList2.SelectedItem.Text = "--select--";
        TextBox1.Text = "";
        TextBox2.Text = "";

    }
    protected void Page_Load(object sender, EventArgs e)
    {
        txt_lid.Text = c.autoid("E", "select * from empreg");
    }
    protected void btn_submit_Click(object sender, EventArgs e)
    {
        c.cmd.CommandText = "select * from empreg";
        c.ds.Clear();
        c.adp.Fill(c.ds, "reg");
        c.dr = c.ds.Tables["reg"].NewRow();
        c.dr["empid"] = txt_lid.Text;
        c.dr["name"] = txt_name.Text;
        c.dr["password"] = txt_pass.Text;
        c.dr["sex"] = DropDownList2.SelectedItem.Text;
        c.dr["dob"] = TextBox1.Text;
        c.dr["department"] = DropDownList1.SelectedItem.Text;
        c.dr["designation"] = ddl_department.SelectedItem.Text;
        c.dr["phonenumber"] = txt_phno.Text;
        c.dr["addres"] = txt_add.Text;
        c.dr["email"] = txt_email.Text;
        c.dr["city"] = TextBox2.Text;
        c.ds.Tables["reg"].Rows.Add(c.dr);
        c.scb = new System.Data.SqlClient.SqlCommandBuilder(c.adp);
        c.adp.Update(c.ds.Tables["reg"]);
        Response.Write("<script>alert('successfully insert data')</script>");
        clear();
    }
    protected void btn_reset_Click(object sender, EventArgs e)
    {
        c.cmd.CommandText = "update empreg set name='" + txt_name.Text + "',password='" + txt_pass.Text + "',department='" + ddl_department.SelectedItem.Text + "',designation='"+DropDownList1.SelectedItem.Text+"',phonenumber='" + txt_phno.Text + "',addres='" + txt_add.Text + "',email='" + txt_email.Text + "' where empid='" + txt_lid.Text + "'";
        c.con.Open();
        c.cmd.ExecuteNonQuery();
        c.con.Close();
        Response.Write("<script>alert('successful update data')</script>");
        clear();
    }
    protected void btn_cancel_Click(object sender, EventArgs e)
    {
        c.cmd.CommandText = "delete from empreg  where empid='"+txt_lid.Text+"'";
        c.con.Open();
        c.cmd.ExecuteNonQuery();
        c.con.Close();
        Response.Write("<script>alert('successful delete data')</script>");
        clear();
    }
   

     }
