﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_emailid : System.Web.UI.Page
{
    Class1 c = new Class1();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        c.con.Open();
        c.cmd.CommandText = "select * from acctype where email='" + TextBox1.Text + "'";
        c.adp.Fill(c.ds, "vt");
        if (c.ds.Tables["vt"].Rows.Count > 0)
        {
            Session["mail"] = TextBox1.Text;
            Response.Redirect("~/Admin/mailing.aspx");
        }
    }
}