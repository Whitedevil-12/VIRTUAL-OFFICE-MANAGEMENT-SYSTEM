﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_addnews : System.Web.UI.Page
{
    Class1 c = new Class1();
    public void clear()
    {
        txt_id.Text = "";
        txt_date.Text = "";
        txt_topic.Text = "";
        txt_desc.Text = "";
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        txt_id.Text = c.autoid("N", "select * from news");
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        c.cmd.CommandText = "select * from news";
        c.ds.Clear();
        c.adp.Fill(c.ds, "reg");
        c.dr = c.ds.Tables["reg"].NewRow();
        c.dr["id"] = txt_id.Text;
        c.dr["date"] = txt_date.Text;
        c.dr["topic"] = txt_topic.Text;
        c.dr["descr"] = txt_desc.Text;
        c.ds.Tables["reg"].Rows.Add(c.dr);
        c.scb = new System.Data.SqlClient.SqlCommandBuilder(c.adp);
        c.adp.Update(c.ds.Tables["reg"]);
        Response.Write("<script>alert('successfully add news')</script>");
        clear();
    }
}