﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_newseditor : System.Web.UI.Page
{
    Class1 c = new Class1();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            c.bindgridview(GridView1, "select * from news");
        }
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        c.bindgridview(GridView1, "select * from news");
    }
    protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GridView1.EditIndex = -1;
        c.bindgridview(GridView1, "select * from news");
    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        c.cmd.CommandText = "delete from news where id='" + GridView1.DataKeys[e.RowIndex].Value.ToString() + "'";
        c.con.Open();
        c.cmd.ExecuteNonQuery();
        c.con.Close();
        c.bindgridview(GridView1, "select * from news");
    }
    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        GridView1.EditIndex = e.NewEditIndex;
        c.bindgridview(GridView1, "select * from news");
    }
    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        GridViewRow gr = GridView1.Rows[e.RowIndex];
        TextBox txtdate = (TextBox)gr.Cells[1].Controls[0];
        TextBox txttopic = (TextBox)gr.Cells[2].Controls[0];
        TextBox txtdesc = (TextBox)gr.Cells[3].Controls[0];
        c.cmd.CommandText = "update news set date='"+txtdate.Text+"',topic='"+txttopic.Text+"',descr='"+txtdesc.Text+"' where id='" + GridView1.DataKeys[e.RowIndex].Value.ToString() + "'";
        c.con.Open();
        c.cmd.ExecuteNonQuery();
        c.con.Close();
        GridView1.EditIndex = -1;
        c.bindgridview(GridView1, "select * from news");
    }
}