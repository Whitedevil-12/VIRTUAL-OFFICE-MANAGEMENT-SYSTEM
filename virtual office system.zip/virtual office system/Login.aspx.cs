﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Login : System.Web.UI.Page
{
    Class1 c = new Class1();
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        if (DropDownList1.SelectedItem.Text == "ADMIN")
        {
            c.con.Open();
            c.cmd.CommandText = "select * from acctype where username='" + TextBox1.Text + "' and password='" + TextBox2.Text + "'";
            c.adp.Fill(c.ds, "vt");
            if (c.ds.Tables["vt"].Rows.Count > 0)
            {
                Response.Redirect("~/Admin/welcome.aspx");
            }
        }
        else
        {
            c.con.Open();
            c.cmd.CommandText = "select * from empreg where empid='" + TextBox1.Text + "' and password='" + TextBox2.Text + "'";
            c.adp.Fill(c.ds, "vt");
            if (c.ds.Tables["vt"].Rows.Count > 0)
            {
                Session["user"] = TextBox1.Text;
                Response.Redirect("~/Employee/welcome.aspx");
            }
        }
    }

    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        if (DropDownList1.SelectedItem.Text == "ADMIN")
        {
            Response.Redirect("~/Admin/forget password.aspx");
        }
        else
        {
            Response.Redirect("~/Employee/forget password.aspx");
        }
    }
}