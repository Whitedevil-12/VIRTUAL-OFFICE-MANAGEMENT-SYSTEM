﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_forget_password : System.Web.UI.Page
{
    Class1 c = new Class1();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        c.ds.Clear();
        c.cmd.CommandText = "select * from empreg where name='" + TextBox1.Text + "' and email='"+TextBox3.Text+"' and dob='"+TextBox4.Text+"' ";
        c.adp.Fill(c.ds, "reg");
        if (c.ds.Tables["reg"].Rows.Count > 0)
        {

            TextBox2.Text = c.ds.Tables["reg"].Rows[0]["password"].ToString();
            Response.Write("<script>alert('successful recover')</script>");
            
        }
        Response.Redirect("~/Login.aspx");
    }
}