﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web;
using System.Net.Mail;

public partial class Employee_clientmail : System.Web.UI.Page
{
    Class1 c = new Class1();
    string str = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
         try
        {
            MailMessage msg = new MailMessage();
            msg.From = new MailAddress(txtUsername.Text);
            msg.To.Add(txtTo.Text);
            msg.Subject = txtSubject.Text;
            msg.Body = txtBody.Text;
           
            //if (FileUpload1.HasFile)
            //{
            //    str = FileUpload1.PostedFile.FileName;
            //    Attachment att = new Attachment(str);
            //    msg.Attachments.Add(att);
                
            //}

            if (FileUpload1.HasFile)
            {
                msg.Attachments.Add(new Attachment(FileUpload1.PostedFile.InputStream, FileUpload1.FileName));
            }
            
            SmtpClient smtp = new SmtpClient();
            smtp.Host = "smtp.gmail.com";
            smtp.Port = 587;
            smtp.Credentials = new System.Net.NetworkCredential(txtUsername.Text, txtpwd.Text);
            smtp.EnableSsl = true;
            smtp.Send(msg);
            msg = null;
            Response.Write("<script>alert('Mail sent')</script>");
            //Page.RegisterStartupScript("usermsg", "<script>alert('Mail Sent Thankyou...')if(alert){window.location='Mailsendingdemo.aspx';}</script>");
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }
    
}