﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Employee_composemail : System.Web.UI.Page
{
    Class1 c = new Class1();
    public void clear()
    {
        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox3.Text = "";
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        Label2.Text = Session["mail"].ToString();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        c.cmd.CommandText = "select * from mail";
        c.ds.Clear();
        c.adp.Fill(c.ds, "vt");
        c.dr = c.ds.Tables["vt"].NewRow();
        c.dr["fro"] = Label2.Text;
        c.dr["t"] = TextBox1.Text;
        c.dr["sub"] = TextBox2.Text;
        c.dr["mess"] = TextBox3.Text;
        c.ds.Tables["vt"].Rows.Add(c.dr);
        c.scb = new System.Data.SqlClient.SqlCommandBuilder(c.adp);
        c.adp.Update(c.ds.Tables["vt"]);
        Response.Write("<script>alert('your message has been sent')</script>");
        Response.Redirect("~/Admin/mailing.aspx");
        clear();
    }
    
}