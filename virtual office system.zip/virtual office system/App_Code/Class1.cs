﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;


public class Class1
{
    public SqlConnection con = new SqlConnection();
    public SqlCommand cmd = new SqlCommand();
    public DataSet ds = new DataSet();
    public SqlDataAdapter adp = new SqlDataAdapter();
    public SqlCommandBuilder scb = new SqlCommandBuilder();
    public DataRow dr;
	public Class1()
	{
        con.ConnectionString = ConfigurationManager.ConnectionStrings["IMEConnectionString"].ConnectionString;
        cmd.Connection = con;
        adp.SelectCommand = cmd;
	}
    public void binddrop(DropDownList id, string query, string text)
    {
        ds.Clear();
        cmd.CommandText = query;
        adp.Fill(ds, "reg");
        id.DataSource = ds.Tables["reg"];
        id.DataTextField = text;
        id.DataValueField = text;
        id.DataBind();
        id.Items.Insert(0, "--Select--");
    }
    public void binddrop1(DropDownList id, string query, string t, string q)
    {
        ds.Clear();
        cmd.CommandText = query;
        adp.Fill(ds, "vt");
        id.DataSource = ds.Tables["vt"];
        id.DataTextField = t;
        id.DataValueField = q;
        id.DataBind();
        id.Items.Insert(0, "--Select--");
    }

    public void bindgridview(GridView id, string query)
    {
        ds.Clear();
        cmd.CommandText = query;
        adp.Fill(ds, "reg");
        id.DataSource = ds.Tables["reg"];
        id.DataBind();
    }
    public string autoid(string text, string q)
    {
        ds.Clear();
        cmd.CommandText = q;
        adp.Fill(ds, "reg");
        return (text + (ds.Tables["reg"].Rows.Count) + 1);
    }
}